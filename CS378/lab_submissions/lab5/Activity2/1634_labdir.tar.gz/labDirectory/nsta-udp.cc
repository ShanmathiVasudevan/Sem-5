/*
 * =============================================================================
 *  nsta-udp.cc  --  CSMA/CA uplink throughput vs. number of stations
 * =============================================================================
 *
 *  SIMULATED NETWORK
 *  -----------------
 *      1 Access Point (AP)  +  N uplink Stations (STAs), single BSS, 802.11a.
 *
 *          STA_1  \
 *          STA_2   \
 *            ...    >----(YansWifiChannel)----  AP  (traffic sink)
 *          STA_N  /
 *
 *      - PHY  : 802.11a OFDM, constant rate, DataMode = OfdmRate48Mbps
 *               (control frames use OfdmRate6Mbps). => PHY bitrate 48 Mbps.
 *      - MAC  : DCF / CSMA-CA (this is what we are studying).
 *      - IP   : 10.1.4.0/24.  The AP device is addressed first, so
 *               AP = 10.1.4.1 and the first STA = 10.1.4.2, next .3, ...
 *      - APP  : each STA runs a UDP OnOff source aimed at the AP, offering
 *               50 Mbps with a 1000-byte UDP payload (=> 1028 bytes handed to
 *               the link layer:  1000 UDP data + 8 UDP hdr + 20 IPv4 hdr).
 *               Each STA sends to its own UDP port (9000 + i) so throughput
 *               can be measured per-uplink.
 *
 *  OUTPUT
 *  ------
 *      - csma-ca-nsta-udp-<N>.txt : one line per 1-second interval (N=#uplinks):
 *            <time> <rx_mbps_uplink0> <rx_mbps_uplink1> ...
 *        (received application-layer throughput of each uplink that second).
 *        Feed this file to summarize.py.
 *      - PCAP  : AP-0-0.pcap  and  Cli-<i>-0.pcap  (one per node).
 *                => number of pcap files = uplinks + 1.
 *
 *  HOW TO RUN  (from ns-3.37 root, after ./ns3 build)
 *  --------------------------------------------------
 *      ./ns3 run "nsta-udp --uplinks=1"
 *      ./ns3 run "nsta-udp --uplinks=5"
 *      time -p ./ns3 run "nsta-udp --uplinks=1"
 *
 *  Useful stdout lines report the app data rate, PHY bitrate and payload sizes.
 * =============================================================================
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include <string>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("NstaUdp");

static const uint32_t UDP_PAYLOAD = 1000;   // bytes of application data per packet
static const std::string PHY_RATE  = "OfdmRate48Mbps";
static const std::string APP_RATE  = "50Mbps";

static std::vector<Ptr<PacketSink>> g_sinks;
static std::vector<uint64_t>        g_lastRx;
static std::ofstream                g_out;
static double                       g_measureInterval = 1.0; // seconds

// Called every g_measureInterval seconds: log per-uplink received throughput.
void Measure()
{
    double now = Simulator::Now().GetSeconds();
    g_out << now;
    for (uint32_t i = 0; i < g_sinks.size(); ++i)
    {
        uint64_t cur   = g_sinks[i]->GetTotalRx();
        uint64_t delta = cur - g_lastRx[i];
        g_lastRx[i]    = cur;
        double mbps    = (delta * 8.0) / (g_measureInterval * 1e6);
        g_out << " " << mbps;
    }
    g_out << std::endl;
    Simulator::Schedule(Seconds(g_measureInterval), &Measure);
}

int main(int argc, char *argv[])
{
    uint32_t uplinks = 1;      // number of STA uplinks
    double   simTime = 4.0;    // seconds of application traffic
    bool     pcap    = true;

    CommandLine cmd(__FILE__);
    cmd.AddValue("uplinks", "Number of uplink stations (STAs)", uplinks);
    cmd.AddValue("simTime", "Application traffic duration (s)", simTime);
    cmd.AddValue("pcap",    "Enable pcap tracing", pcap);
    cmd.Parse(argc, argv);

    NS_ABORT_MSG_IF(uplinks < 1, "Need at least one uplink");

    // ---- Nodes -------------------------------------------------------------
    NodeContainer apNode;   apNode.Create(1);
    NodeContainer staNodes; staNodes.Create(uplinks);

    // ---- PHY / channel -----------------------------------------------------
    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211a);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",    StringValue(PHY_RATE),
                                 "ControlMode", StringValue("OfdmRate6Mbps"));

    WifiMacHelper mac;
    Ssid ssid = Ssid("csma-ca-lab");

    mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer staDevices = wifi.Install(phy, mac, staNodes);

    mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
    NetDeviceContainer apDevice = wifi.Install(phy, mac, apNode);

    // ---- Mobility (all stationary, co-located BSS) -------------------------
    MobilityHelper mobility;
    Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator>();
    pos->Add(Vector(0.0, 0.0, 0.0));                 // AP at origin
    for (uint32_t i = 0; i < uplinks; ++i)
        pos->Add(Vector(1.0 + i, 0.0, 0.0));         // STAs a few metres away
    mobility.SetPositionAllocator(pos);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(apNode);
    mobility.Install(staNodes);

    // ---- Internet stack ----------------------------------------------------
    InternetStackHelper stack;
    stack.Install(apNode);
    stack.Install(staNodes);

    Ipv4AddressHelper address;
    address.SetBase("10.1.4.0", "255.255.255.0");
    Ipv4InterfaceContainer apIface  = address.Assign(apDevice);   // 10.1.4.1
    Ipv4InterfaceContainer staIface = address.Assign(staDevices); // 10.1.4.2 ...

    Ipv4Address apAddr = apIface.GetAddress(0);

    // ---- Applications: uplink UDP OnOff STA -> AP --------------------------
    ApplicationContainer sinkApps, srcApps;
    for (uint32_t i = 0; i < uplinks; ++i)
    {
        uint16_t port = 9000 + i;

        PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer s = sinkHelper.Install(apNode.Get(0));
        sinkApps.Add(s);
        g_sinks.push_back(DynamicCast<PacketSink>(s.Get(0)));
        g_lastRx.push_back(0);

        OnOffHelper onoff("ns3::UdpSocketFactory", InetSocketAddress(apAddr, port));
        onoff.SetAttribute("OnTime",  StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        onoff.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        onoff.SetAttribute("DataRate",   DataRateValue(DataRate(APP_RATE)));
        onoff.SetAttribute("PacketSize", UintegerValue(UDP_PAYLOAD));
        srcApps.Add(onoff.Install(staNodes.Get(i)));
    }

    sinkApps.Start(Seconds(0.0));
    sinkApps.Stop(Seconds(simTime + 0.2));
    srcApps.Start(Seconds(0.0));
    srcApps.Stop(Seconds(simTime));

    // ---- Tracing -----------------------------------------------------------
    if (pcap)
    {
        phy.SetPcapDataLinkType(WifiPhyHelper::DLT_IEEE802_11_RADIO);
        phy.EnablePcap("AP",  apDevice);    // -> AP-0-0.pcap
        phy.EnablePcap("Cli", staDevices);  // -> Cli-1-0.pcap, Cli-2-0.pcap, ...
    }

    // Output name encodes the number of uplinks so runs for different
    // instances (1/5/10/20/30) do NOT overwrite each other -- the autograder
    // reads each csma-ca-nsta-udp-<N>.txt to compute the reference metrics.
    std::string outName = "csma-ca-nsta-udp-" + std::to_string(uplinks) + ".txt";
    g_out.open(outName.c_str());
    Simulator::Schedule(Seconds(g_measureInterval), &Measure);

    // ---- Report configuration to stdout ------------------------------------
    std::cout << "==================== nsta-udp configuration ====================\n";
    std::cout << "Uplinks (STAs)            : " << uplinks << "\n";
    std::cout << "Application data rate      : 50 Mbps (per uplink)\n";
    std::cout << "PHY layer bitrate          : 48 Mbps (OfdmRate48Mbps)\n";
    std::cout << "UDP payload                : " << UDP_PAYLOAD << " bytes\n";
    std::cout << "Link-layer payload (fr IP) : " << (UDP_PAYLOAD + 8 + 20) << " bytes\n";
    std::cout << "AP IP address              : " << apAddr << "\n";
    if (uplinks >= 1)
        std::cout << "First STA IP address       : " << staIface.GetAddress(0) << "\n";
    std::cout << "PCAP files generated       : " << (uplinks + 1)
              << "  (AP-0-0.pcap + Cli-*-0.pcap)\n";
    std::cout << "================================================================\n";

    Simulator::Stop(Seconds(simTime + 0.3));
    Simulator::Run();
    Simulator::Destroy();
    g_out.close();

    std::cout << "[done] Per-second throughput written to " << outName << "\n";
    return 0;
}
