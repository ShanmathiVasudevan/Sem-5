#!/usr/bin/env python3
"""
summarize.py -- summarize the per-second uplink throughput produced by nsta-udp.

Input file (e.g. csma-ca-nsta-udp-5.txt for the 5-node run), one line per 1-second interval:

    <time> <mbps_uplink0> <mbps_uplink1> ...

For every interval it computes, across the uplinks:
    Min   = minimum per-uplink throughput
    Max   = maximum per-uplink throughput
    Total = sum of per-uplink throughput (aggregate offered to the channel)

It then reports the two lab metrics:
    Avg. Throughput     = mean of the per-interval Total values
    Avg. Min/Max ratio  = mean of the per-interval (Min/Max) ratios

Usage:
    python3 summarize.py [input_file] [--plot] [--roll ROLLNO]

    --plot         also save throughput.png and minmax_ratio.png (needs matplotlib)
    --roll ROLLNO  put your roll number in the plot titles (required by the quiz)
"""

import sys
import argparse


def load(path):
    """Return list of (time, [per-uplink mbps...]) rows."""
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            t = float(parts[0])
            vals = [float(x) for x in parts[1:]]
            if vals:
                rows.append((t, vals))
    return rows


def summarize(rows):
    """Print the Time,Min,Max,Total table and return (avg_total, avg_minmax)."""
    print("Time,Min,Max,Total")
    totals, ratios = [], []
    times, tvals, minvals, maxvals = [], [], [], []
    for t, vals in rows:
        mn, mx, tot = min(vals), max(vals), sum(vals)
        print(f"{t:.1f},{mn:.4f},{mx:.4f},{tot:.4f}")
        totals.append(tot)
        ratios.append((mn / mx) if mx > 0 else 0.0)
        times.append(t); tvals.append(tot); minvals.append(mn); maxvals.append(mx)

    avg_total = sum(totals) / len(totals) if totals else 0.0
    avg_ratio = sum(ratios) / len(ratios) if ratios else 0.0
    print("-" * 40)
    print(f"Avg. Throughput    : {avg_total:.4f} Mbps")
    print(f"Avg. Min/Max ratio : {avg_ratio:.4f}")
    return avg_total, avg_ratio, times, tvals


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", nargs="?", default="csma-ca-nsta-udp.txt")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--roll", default="")
    args = ap.parse_args()

    rows = load(args.input)
    if not rows:
        print(f"[!] No data in {args.input}", file=sys.stderr)
        sys.exit(1)

    avg_total, avg_ratio, times, tvals = summarize(rows)

    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            print("[!] matplotlib not installed; skipping plots", file=sys.stderr)
            return
        plt.figure()
        plt.plot(times, tvals, marker="o")
        plt.xlabel("Time (s)")
        plt.ylabel("Total throughput (Mbps)")
        plt.title(f"Per-second total throughput  {args.roll}".strip())
        plt.grid(True)
        plt.savefig("throughput.png")
        print("[+] Saved throughput.png")


if __name__ == "__main__":
    main()
