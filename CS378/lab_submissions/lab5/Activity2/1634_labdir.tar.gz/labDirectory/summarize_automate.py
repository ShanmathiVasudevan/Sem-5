#!/usr/bin/env python3
"""
summarize_automate.py -- Part-2 automation for the CSMA/CA efficiency lab.

Runs nsta-udp for each network instance (1, 5, 10, 20, 30 clients), collects
the per-second uplink throughput, computes the two lab metrics for each
instance, and produces the two required line-plots-with-markers:

    avg_throughput.png     : #nodes  vs  Avg. Throughput (Mbps)
    avg_minmax_ratio.png   : #nodes  vs  Avg. Min/Max ratio

Run from /home/labDirectory (where the ./nsta-udp launcher lives), AFTER
`bash setup_ns3.sh` has built ns-3 and created the launcher:

    python3 summarize_automate.py --roll <YOUR_ROLL_NO>

Requires pandas/matplotlib only for the optional plots:
    pip3 install pandas matplotlib
"""

import argparse
import subprocess
import os

NODE_COUNTS = [1, 5, 10, 20, 30]
# nsta-udp.cc (metrics build) writes csma-ca-nsta-udp-<N>.txt


def run_instance(n):
    """Run nsta-udp with n uplinks; return (avg_total, avg_minmax)."""
    print(f"\n=== Running nsta-udp with {n} client(s) ===")
    subprocess.run(["./nsta-udp", f"--uplinks={n}"], check=True)

    out_file = f"csma-ca-nsta-udp-{n}.txt"
    totals, ratios = [], []
    with open(out_file) as f:
        for line in f:
            parts = line.split()
            if len(parts) < 2:
                continue
            vals = [float(x) for x in parts[1:]]
            mn, mx, tot = min(vals), max(vals), sum(vals)
            totals.append(tot)
            ratios.append((mn / mx) if mx > 0 else 0.0)

    avg_total = sum(totals) / len(totals) if totals else 0.0
    avg_ratio = sum(ratios) / len(ratios) if ratios else 0.0
    print(f"  Avg. Throughput    = {avg_total:.4f} Mbps")
    print(f"  Avg. Min/Max ratio = {avg_ratio:.4f}")
    return avg_total, avg_ratio


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--roll", default="", help="your roll number (goes in plot titles)")
    args = ap.parse_args()

    if not os.path.exists("./nsta-udp"):
        print("[!] ./nsta-udp launcher not found. Run this from /home/labDirectory "
              "after `bash setup_ns3.sh` (which builds ns-3 and makes the launcher).")
        return

    xs, thr, ratio = [], [], []
    for n in NODE_COUNTS:
        a, r = run_instance(n)
        xs.append(n); thr.append(a); ratio.append(r)

    print("\n================= SUMMARY =================")
    print(f"{'nodes':>6} {'AvgThroughput':>15} {'AvgMin/Max':>12}")
    for n, a, r in zip(xs, thr, ratio):
        print(f"{n:>6} {a:>15.4f} {r:>12.4f}")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n[!] matplotlib not installed; skipping plots (pip3 install matplotlib)")
        return

    plt.figure()
    plt.plot(xs, thr, marker="o")
    plt.xlabel("Number of client nodes")
    plt.ylabel("Avg. Throughput (Mbps)")
    plt.title(f"CSMA/CA Avg. Throughput vs #nodes  [{args.roll}]")
    plt.grid(True)
    plt.savefig("avg_throughput.png")

    plt.figure()
    plt.plot(xs, ratio, marker="o")
    plt.xlabel("Number of client nodes")
    plt.ylabel("Avg. Min/Max ratio")
    plt.title(f"CSMA/CA Fairness (Avg. Min/Max) vs #nodes  [{args.roll}]")
    plt.grid(True)
    plt.savefig("avg_minmax_ratio.png")
    print("\n[+] Saved avg_throughput.png and avg_minmax_ratio.png")


if __name__ == "__main__":
    main()
