#!/usr/bin/env bash
# =====================================================================
#  setup_ns3.sh  —  one-shot ns-3 setup for the CSMA/CA labs
# ---------------------------------------------------------------------
#  What it does (all inside /home/labDirectory, which persists):
#    1. Copies ns-3.41 from /opt (offline, fast) — or wgets it as fallback.
#    2. Stages every *.cc in /home/labDirectory into ns-3's scratch/.
#    3. Configures the minimal WiFi module set.
#    4. Builds ns-3 + the scratch programs, showing a live % + ETA.
#
#  Re-running is safe: an existing tree is reused and the build is
#  incremental (pass --force to wipe and start over).
#
#  Usage:
#    bash /home/labDirectory/setup_ns3.sh          # copy from /opt (default)
#    bash /home/labDirectory/setup_ns3.sh --wget   # force download instead
#    bash /home/labDirectory/setup_ns3.sh --force  # rebuild from scratch
# =====================================================================
set -euo pipefail

# ---- Config ---------------------------------------------------------
LAB=/home/labDirectory
VER=ns-allinone-3.41
NS3_VER=ns-3.41
MODULES="wifi,internet,applications,mobility,propagation"
TARBALL_URL="https://www.nsnam.org/releases/${VER}.tar.bz2"

# FLAT=0 -> ns-3 tree lives in the /home/labDirectory/ns-3.41 subfolder (tidy);
#           a small launcher is placed in /home/labDirectory so you run the
#           built program as ./nsta-udp WITHOUT entering the tree. (default)
# FLAT=1 -> ns-3 tree lives directly at /home/labDirectory (clutters ls).
FLAT=0

USE_WGET=0
FORCE=0
for arg in "$@"; do
  case "$arg" in
    --wget)  USE_WGET=1 ;;
    --force) FORCE=1 ;;
    --flat)  FLAT=1 ;;
    --subfolder) FLAT=0 ;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

if [ "$FLAT" -eq 1 ]; then NS3_HOME="$LAB"; else NS3_HOME="$LAB/$NS3_VER"; fi

# ---- Pretty helpers -------------------------------------------------
BOLD=$'\033[1m'; DIM=$'\033[2m'; GRN=$'\033[32m'; YLW=$'\033[33m'; RST=$'\033[0m'
STEP=0
hms() { local s=$1; printf '%02d:%02d' $((s/60)) $((s%60)); }
step() { STEP=$((STEP+1)); echo; echo "${BOLD}==> [${STEP}] $*${RST}"; }
ok()   { echo "${GRN}    ok${RST} ($*)"; }
note() { echo "${DIM}    $*${RST}"; }

TOTAL_START=$SECONDS
trap 'echo; echo "${YLW}Setup stopped after $(hms $((SECONDS-TOTAL_START))).${RST}"' EXIT

# ---- 0. Sanity ------------------------------------------------------
step "Preparing (${BOLD}NS3_HOME=${NS3_HOME}${RST}${BOLD}, FLAT=${FLAT}${RST})"
mkdir -p "$LAB"
cd "$LAB"
CORES=$(nproc 2>/dev/null || echo 2)
note "detected ${CORES} CPU core(s) — more cores = faster build"

# ---- 1. Obtain ns-3 -------------------------------------------------
NS3_READY=0
if [ -x "$NS3_HOME/ns3" ] && [ "$FORCE" -eq 0 ]; then
  step "ns-3 already present at $NS3_HOME — skipping copy (use --force to redo)"
  NS3_READY=1
else
  [ "$FORCE" -eq 1 ] && { step "Wiping existing tree (--force)"; rm -rf "$NS3_HOME/$NS3_VER" "$NS3_HOME/ns3" "$NS3_HOME/src" "$NS3_HOME/build" 2>/dev/null || true; }

  # Locate a source under /opt (extracted dir preferred, else tarball).
  SRC_DIR=""; SRC_TAR=""
  if   [ -d "/opt/$VER/$NS3_VER" ]; then SRC_DIR="/opt/$VER/$NS3_VER"
  elif [ -d "/opt/$NS3_VER" ];      then SRC_DIR="/opt/$NS3_VER"
  elif [ -f "/opt/${VER}.tar.bz2" ]; then SRC_TAR="/opt/${VER}.tar.bz2"
  else SRC_TAR="$(ls /opt/${VER}*.tar.bz2 2>/dev/null | head -1 || true)"; fi

  if [ "$USE_WGET" -eq 1 ]; then SRC_DIR=""; SRC_TAR=""; fi

  if [ -n "$SRC_DIR" ]; then
    step "Copying ns-3 from $SRC_DIR  (${DIM}this is I/O bound, ~1-2 min${RST})"
    if command -v rsync >/dev/null 2>&1; then
      rsync -a --info=progress2 "$SRC_DIR/" "$LAB/.ns3_src/"
    else
      cp -a "$SRC_DIR" "$LAB/.ns3_src"
    fi
  else
    if [ -z "$SRC_TAR" ]; then
      step "Downloading ns-3 from nsnam.org  (${DIM}~40 MB${RST})"
      wget -O "$LAB/${VER}.tar.bz2" "$TARBALL_URL"
      SRC_TAR="$LAB/${VER}.tar.bz2"
    else
      step "Using tarball $SRC_TAR"
    fi
    step "Extracting $(basename "$SRC_TAR")  (${DIM}~1 min${RST})"
    rm -rf "$LAB/.ns3_extract"; mkdir -p "$LAB/.ns3_extract"
    tar xjf "$SRC_TAR" -C "$LAB/.ns3_extract"
    if   [ -d "$LAB/.ns3_extract/$VER/$NS3_VER" ]; then mv "$LAB/.ns3_extract/$VER/$NS3_VER" "$LAB/.ns3_src"
    elif [ -d "$LAB/.ns3_extract/$NS3_VER" ];      then mv "$LAB/.ns3_extract/$NS3_VER" "$LAB/.ns3_src"
    else echo "could not find $NS3_VER inside the archive" >&2; exit 1; fi
    rm -rf "$LAB/.ns3_extract"
  fi

  # Place the ns-3.41 tree at NS3_HOME.
  step "Placing ns-3 at $NS3_HOME"
  if [ "$FLAT" -eq 1 ]; then
    mkdir -p "$NS3_HOME"; cp -a "$LAB/.ns3_src/." "$NS3_HOME/"
  else
    rm -rf "$NS3_HOME"; mv "$LAB/.ns3_src" "$NS3_HOME"
  fi
  rm -rf "$LAB/.ns3_src"
  ok "ns-3 tree ready"
fi

cd "$NS3_HOME"
[ -x ./ns3 ] || { echo "ns3 wrapper not found in $NS3_HOME" >&2; exit 1; }

# ---- 2. Stage the lab's .cc sources into scratch/ -------------------
step "Staging simulation sources into scratch/"
mkdir -p scratch
shopt -s nullglob
staged=0
for cc in "$LAB"/*.cc; do
  cp -f "$cc" scratch/
  note "staged $(basename "$cc")"
  staged=$((staged+1))
done
shopt -u nullglob
[ "$staged" -gt 0 ] || note "no *.cc found in $LAB (nothing to stage)"
ok "$staged source file(s)"

# ---- 3. Configure ---------------------------------------------------
step "Configuring ns-3  (modules: $MODULES)"
cfg_start=$SECONDS
./ns3 configure --enable-modules "$MODULES" >/tmp/ns3_configure.log 2>&1 \
  || { echo "configure failed — see /tmp/ns3_configure.log"; tail -30 /tmp/ns3_configure.log; exit 1; }
ok "configured in $(hms $((SECONDS-cfg_start)))"

# ---- 4. Build with live %+ETA --------------------------------------
step "Building ns-3 + scratch  (${DIM}first build is the slow one${RST})"
note "full build log -> $NS3_HOME/build.log"
BUILD_LOG="$NS3_HOME/build.log"; : > "$BUILD_LOG"
RC_FILE="$(mktemp)"

# Run the build in the background; capture its real exit code.
( ./ns3 build >"$BUILD_LOG" 2>&1; echo $? >"$RC_FILE" ) &
BPID=$!

bstart=$SECONDS
last=""
while kill -0 "$BPID" 2>/dev/null; do
  # ninja prints counters like "[1234/5678] ..."; grab the most recent N/N.
  prog=$(grep -oE '[0-9]+/[0-9]+' "$BUILD_LOG" 2>/dev/null | tail -1 || true)
  el=$((SECONDS-bstart))
  if [ -n "$prog" ]; then
    cur=${prog%%/*}
    tot=${prog##*/}
    if [ "${cur:-0}" -gt 0 ] 2>/dev/null && [ "${tot:-0}" -gt 0 ] 2>/dev/null; then
      pct=$(( cur*100/tot ))
      # ETA = elapsed * (remaining / done)
      eta=$(( el*(tot-cur)/cur ))
      last=$(printf '  [%3d%%] %d/%d compiled  elapsed %s  ~ETA %s' \
               "$pct" "$cur" "$tot" "$(hms "$el")" "$(hms "$eta")")
    else
      last=$(printf '  preparing...  elapsed %s' "$(hms "$el")")
    fi
  else
    last=$(printf '  configuring/cmake...  elapsed %s' "$(hms "$el")")
  fi
  printf '\r%-72s' "$last"
  sleep 3
done
wait "$BPID" 2>/dev/null || true
rc=$(cat "$RC_FILE" 2>/dev/null || echo 1); rm -f "$RC_FILE"
printf '\r%-72s\r' ' '

if [ "$rc" -ne 0 ]; then
  echo "${YLW}Build FAILED (exit $rc). Last 30 lines:${RST}"
  tail -30 "$BUILD_LOG"
  echo "Full log: $BUILD_LOG"
  exit "$rc"
fi
ok "built in $(hms $((SECONDS-bstart)))"

# ---- 5. Install run launchers in /home/labDirectory -----------------
# So students run ./nsta-udp straight from /home/labDirectory instead of
# entering the ns-3 tree. The launcher execs the freshly-built binary with
# LD_LIBRARY_PATH set, and (being run from /home/labDirectory) writes the
# sim's output files right here.
step "Installing run launcher(s) in /home/labDirectory"
LIBDIR="$NS3_HOME/build/lib"
made=0
shopt -s nullglob
for cc in "$LAB"/*.cc; do
  prog=$(basename "$cc" .cc)
  # ns-3 names scratch binaries like ns3.41-<prog>-default; match loosely.
  bin=$(find "$NS3_HOME/build/scratch" -type f -perm -u+x -name "*${prog}*" \
          ! -name '*.o' 2>/dev/null | head -1)
  if [ -z "$bin" ]; then note "no binary found for $prog — skipped"; continue; fi
  launcher="$LAB/$prog"
  cat > "$launcher" <<EOF
#!/usr/bin/env bash
# Auto-generated by setup_ns3.sh — runs the ns-3 program you built.
# Run this from /home/labDirectory; output files are written to your cwd.
exec env LD_LIBRARY_PATH="$LIBDIR\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}" "$bin" "\$@"
EOF
  chmod +x "$launcher"
  note "created ./$prog  ->  ${bin#$LAB/}"
  made=$((made+1))
done
shopt -u nullglob
ok "$made launcher(s)"

# ---- Done -----------------------------------------------------------
trap - EXIT
echo
echo "${GRN}${BOLD}All set.${RST}  ns-3 is built under ${BOLD}$NS3_HOME${RST}"
echo "Total time: $(hms $((SECONDS-TOTAL_START)))"
echo
echo "Run from ${BOLD}/home/labDirectory${RST} using the launcher(s) — no need to"
echo "enter the ns-3 tree. For example:"
echo "    cd /home/labDirectory"
for cc in "$LAB"/*.cc; do
  p=$(basename "$cc" .cc)
  [ -x "$LAB/$p" ] && echo "    ./$p ..."
done
echo
echo "Output files (.txt / .pcap) are written into /home/labDirectory."
echo "Edit answers.txt there, then submit. Re-run this script after editing a .cc."
