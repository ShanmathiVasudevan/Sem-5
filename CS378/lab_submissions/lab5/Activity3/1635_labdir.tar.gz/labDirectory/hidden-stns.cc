/*
 * =============================================================================
 *  hidden-stns.cc  --  Hidden terminal experiment and the effect of RTS/CTS
 * =============================================================================
 *
 *  SIMULATED NETWORK  (3 nodes total)
 *  ----------------------------------
 *      Two sender stations (n1, n2) both transmit UDP uplink traffic to a
 *      single receiver/AP (n0) placed between them.  n1 and n2 are positioned
 *      far apart so that they CANNOT sense each other's carrier -- they are
 *      "hidden" from one another -- while both remain in range of n0.
 *
 *          n1 (STA) ....X.... n0 (AP / receiver) ....X.... n2 (STA)
 *                     hidden               hidden
 *
 *      Because the two senders cannot hear each other, plain CSMA/CA carrier
 *      sensing does not prevent them from transmitting at the same time; their
 *      frames then collide AT THE RECEIVER n0.  RTS/CTS fixes this: the CTS
 *      from n0 is heard by both senders and reserves the channel.
 *
 *  PARAMETERS
 *  ----------
 *      --contention=<0|1>  : 0 = only one sender is active (no contention,
 *                                no interference at the receiver)
 *                            1 = both hidden senders are active (contention,
 *                                collisions occur at receiver n0)
 *      --rtscts=<0|1>      : 0 = RTS/CTS disabled (large threshold)
 *                            1 = RTS/CTS enabled (threshold = 0)
 *
 *  THE FOUR LAB CASES
 *  ------------------
 *      Case 1:  --contention=0 --rtscts=0   (no contention, no RTS/CTS)
 *      Case 2:  --contention=0 --rtscts=1   (no contention, with RTS/CTS)
 *      Case 3:  --contention=1 --rtscts=0   (with contention, no RTS/CTS)
 *      Case 4:  --contention=1 --rtscts=1   (with contention, with RTS/CTS)
 *
 *  OUTPUT
 *  ------
 *      Prints the total channel throughput (sum over receiving flows) in Mbps.
 *
 *  HOW TO RUN  (from ns-3.37 root, after ./ns3 build)
 *  --------------------------------------------------
 *      ./ns3 run "hidden-stns --contention=0 --rtscts=0"   # Case 1
 *      ./ns3 run "hidden-stns --contention=0 --rtscts=1"   # Case 2
 *      ./ns3 run "hidden-stns --contention=1 --rtscts=0"   # Case 3
 *      ./ns3 run "hidden-stns --contention=1 --rtscts=1"   # Case 4
 * =============================================================================
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include "ns3/propagation-module.h"
#include <fstream>
#include <string>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("HiddenStns");

static const uint32_t UDP_PAYLOAD = 1000;
static const std::string PHY_RATE = "OfdmRate48Mbps";
static const std::string APP_RATE = "50Mbps";

int main(int argc, char *argv[])
{
    bool   contention = true;
    bool   rtscts     = false;
    double simTime    = 5.0;

    CommandLine cmd(__FILE__);
    cmd.AddValue("contention", "Both hidden senders active (1) or only one (0)", contention);
    cmd.AddValue("rtscts",     "Enable RTS/CTS (1) or not (0)", rtscts);
    cmd.AddValue("simTime",    "Application traffic duration (s)", simTime);
    cmd.Parse(argc, argv);

    // RTS/CTS threshold: 0 => always use RTS/CTS; huge => never.
    UintegerValue ctsThreshold = rtscts ? UintegerValue(0) : UintegerValue(999999);
    Config::SetDefault("ns3::WifiRemoteStationManager::RtsCtsThreshold", ctsThreshold);

    // ---- Nodes: 0 = receiver/AP (middle), 1 & 2 = hidden senders -----------
    NodeContainer nodes; nodes.Create(3);
    NodeContainer apNode(nodes.Get(0));
    NodeContainer staNodes(nodes.Get(1), nodes.Get(2));

    // ---- Channel with a range-limited propagation loss so the two senders
    //      are hidden from each other but both reach the receiver ------------
    YansWifiPhyHelper phy;
    YansWifiChannelHelper channel;
    channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    channel.AddPropagationLoss("ns3::RangePropagationLossModel",
                               "MaxRange", DoubleValue(120.0)); // reaches ~100m
    phy.SetChannel(channel.Create());

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211a);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode",    StringValue(PHY_RATE),
                                 "ControlMode", StringValue("OfdmRate6Mbps"));

    WifiMacHelper mac;
    Ssid ssid = Ssid("hidden-lab");
    mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer staDevices = wifi.Install(phy, mac, staNodes);
    mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
    NetDeviceContainer apDevice = wifi.Install(phy, mac, apNode);

    // ---- Geometry:  n1 --100m-- n0 --100m-- n2  (n1<->n2 = 200m > range) ----
    MobilityHelper mobility;
    Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator>();
    pos->Add(Vector(100.0, 0.0, 0.0));   // n0 receiver (middle)
    pos->Add(Vector(0.0,   0.0, 0.0));   // n1 sender (left)
    pos->Add(Vector(200.0, 0.0, 0.0));   // n2 sender (right)
    mobility.SetPositionAllocator(pos);
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(nodes);

    // ---- Internet ----------------------------------------------------------
    InternetStackHelper stack;
    stack.Install(nodes);
    Ipv4AddressHelper address;
    address.SetBase("10.1.4.0", "255.255.255.0");
    Ipv4InterfaceContainer apIface  = address.Assign(apDevice);   // 10.1.4.1
    Ipv4InterfaceContainer staIface = address.Assign(staDevices); // 10.1.4.2, .3
    Ipv4Address apAddr = apIface.GetAddress(0);

    // ---- Applications: sender(s) -> receiver n0 ----------------------------
    // Sender n1 is always active. Sender n2 is active only when contention=1.
    uint32_t numSenders = contention ? 2 : 1;

    ApplicationContainer sinkApps, srcApps;
    std::vector<Ptr<PacketSink>> sinks;
    for (uint32_t i = 0; i < numSenders; ++i)
    {
        uint16_t port = 9000 + i;
        PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer s = sinkHelper.Install(apNode.Get(0));
        sinkApps.Add(s);
        sinks.push_back(DynamicCast<PacketSink>(s.Get(0)));

        OnOffHelper onoff("ns3::UdpSocketFactory", InetSocketAddress(apAddr, port));
        onoff.SetAttribute("OnTime",  StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        onoff.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        onoff.SetAttribute("DataRate",   DataRateValue(DataRate(APP_RATE)));
        onoff.SetAttribute("PacketSize", UintegerValue(UDP_PAYLOAD));
        srcApps.Add(onoff.Install(staNodes.Get(i)));
    }

    sinkApps.Start(Seconds(0.0));
    sinkApps.Stop(Seconds(simTime + 0.2));
    srcApps.Start(Seconds(1.0));
    srcApps.Stop(Seconds(simTime));

    Simulator::Stop(Seconds(simTime + 0.3));
    Simulator::Run();

    uint64_t totalRx = 0;
    for (auto &s : sinks) totalRx += s->GetTotalRx();
    double duration = simTime - 1.0;
    double mbps = (totalRx * 8.0) / (duration * 1e6);

    std::cout << "==================== hidden-stns result ====================\n";
    std::cout << "Nodes in network      : 3 (1 receiver + 2 hidden senders)\n";
    std::cout << "Contention            : " << (contention ? "ENABLED (both senders)"
                                                           : "DISABLED (one sender)") << "\n";
    std::cout << "RTS/CTS               : " << (rtscts ? "ENABLED" : "DISABLED") << "\n";
    std::cout << "Total channel throughput : " << mbps << " Mbps\n";
    std::cout << "============================================================\n";

    // Persist the result so the autograder can read it after all 4 runs.
    // File name encodes the case:  hidden-<contention>-<rtscts>.txt
    //   Case 1 -> hidden-0-0.txt   Case 2 -> hidden-0-1.txt
    //   Case 3 -> hidden-1-0.txt   Case 4 -> hidden-1-1.txt
    {
        std::string resName = std::string("hidden-") + (contention ? "1" : "0")
                            + "-" + (rtscts ? "1" : "0") + ".txt";
        std::ofstream rf(resName.c_str());
        rf << mbps << std::endl;
        rf.close();
        std::cout << "[done] Result written to " << resName << "\n";
    }

    Simulator::Destroy();
    return 0;
}
