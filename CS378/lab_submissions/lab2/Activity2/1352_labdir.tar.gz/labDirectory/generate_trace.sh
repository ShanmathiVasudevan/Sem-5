#!/bin/bash
#
# generate_trace.sh (p2 -- Types of Traffic)
#
# Runs once, automatically, at container boot. Generates real ARP,
# ICMP, and SSH traffic and captures it to trace.pcapng in your home
# directory. The ping target and SSH host are picked deterministically
# based on CLAB_USER_NAME (same student always gets the same trace).

set -uo pipefail

CLAB_USER_NAME="${CLAB_USER_NAME:-}"
if [ -z "$CLAB_USER_NAME" ]; then
    echo "WARNING: CLAB_USER_NAME is not set -- falling back to hostname." >&2
    CLAB_USER_NAME="$(hostname)"
fi

TRACE_FILE="$HOME/trace.pcapng"

seeded_shuffle() {
    local salt="$1"; shift
    local item h
    for item in "$@"; do
        h=$(printf '%s' "${CLAB_USER_NAME}:${salt}:${item}" | sha256sum | cut -c1-16)
        echo "$h $item"
    done | sort | awk '{print $2}'
}

seeded_pick_one() {
    local salt="$1"; shift
    seeded_shuffle "$salt" "$@" | head -n1
}

# Public, reliable ICMP-responding IPv4 addresses (public DNS resolvers).
# Plain IPs on purpose -- no DNS lookup needed, keeps the trace focused
# on ARP/ICMP/SSH only.
PING_TARGETS=(www.cse.iitb.ac.in iitb.ac.in google.com)
PING_TARGET="$(seeded_pick_one "p2-ping-target" "${PING_TARGETS[@]}")"

# Public git hosts that always answer an SSH banner on port 22. We
# never authenticate (no valid key) -- we only need the TCP+SSH
# protocol-level exchange, which happens before authentication.
SSH_HOSTS=(github.com gitlab.com)
SSH_HOST="$(seeded_pick_one "p2-ssh-host" "${SSH_HOSTS[@]}")"

print_capture_diagnostics() {
    echo "----- capture diagnostics -----" >&2
    echo "whoami: $(whoami 2>&1)" >&2
    echo "id: $(id 2>&1)" >&2
    echo "effective capabilities (see 'capsh --decode=<hex>' to read):" >&2
    grep -E '^Cap(Inh|Prm|Eff|Bnd)' /proc/self/status 2>&1 >&2
    echo "ip -o link show:" >&2
    ip -o link show 2>&1 >&2
    echo "tshark -D:" >&2
    tshark -D 2>&1 >&2
    echo "dumpcap -D:" >&2
    dumpcap -D 2>&1 >&2
    echo "--------------------------------" >&2
    echo "If every interface (including 'any') fails with ioctl/setsockopt" >&2
    echo "errors like SIOCETHTOOL or SO_TIMESTAMPNS while running as root," >&2
    echo "this is usually NOT a script bug -- it means the container's" >&2
    echo "network stack does not support raw packet capture at all. This" >&2
    echo "is a known limitation on some Docker Desktop for Mac networking" >&2
    echo "modes. Check: (1) the container is run with --cap-add=NET_RAW" >&2
    echo "--cap-add=NET_ADMIN, (2) if running on Docker Desktop for Mac," >&2
    echo "try a real Linux Docker host, or a different Docker Desktop" >&2
    echo "network backend." >&2
}

candidate_interfaces() {
    local route_iface up_iface
    route_iface="$(ip -o route get 8.8.8.8 2>/dev/null \
        | awk '{for(i=1;i<=NF;i++) if ($i=="dev") {print $(i+1); exit}}')"
    up_iface="$(ip -o link show up 2>/dev/null \
        | awk -F': ' '{print $2}' | cut -d'@' -f1 | grep -v '^lo$' | head -n1)"

    local seen=" "
    for cand in "$route_iface" "eth0" "$up_iface"; do
        if [ -n "$cand" ] && [[ "$seen" != *" $cand "* ]]; then
            echo "$cand"
            seen="$seen$cand "
        fi
    done
    echo "any"
}

# ---------------------------------------------------------------------------
# Start a packet capture on the given interface, trying several
# strategies in turn -- see p1's generate_trace.sh for the full
# rationale (some container network runtimes reject the
# ETHTOOL_GET_TS_INFO ioctl / SO_TIMESTAMPNS setsockopt libpcap uses
# by default, which is fatal to a plain "tshark -i ... -w ..." even
# though capture would otherwise work fine).
#
# Sets the globals CAPTURE_PID and CAPTURE_METHOD on success.
# ---------------------------------------------------------------------------
CAPTURE_PID=""
CAPTURE_METHOD=""

start_capture() {
    local iface="$1" file="$2" log="/tmp/capture_attempt.log"
    local pid

    rm -f "$file"
    tshark -i "$iface" --time-stamp-type host -w "$file" -q > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tshark --time-stamp-type host"
        return 0
    fi
    echo "Capture method 'tshark --time-stamp-type host' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tcpdump -i "$iface" -j host -w "$file" > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tcpdump -j host"
        return 0
    fi
    echo "Capture method 'tcpdump -j host' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tcpdump -i "$iface" -w "$file" > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tcpdump (default)"
        return 0
    fi
    echo "Capture method 'tcpdump (default)' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tshark -i "$iface" -w "$file" -q > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tshark (default)"
        return 0
    fi
    echo "Capture method 'tshark (default)' failed on '$iface':" >&2
    cat "$log" >&2

    return 1
}

capture_and_generate_traffic() {
    local iface="$1"
    local gateway
    gateway="$(ip route show default 2>/dev/null | awk '/default/ {print $3; exit}')"
    if [ -z "$gateway" ]; then
        echo "Could not determine default gateway"
        return 1
    fi

    if ! start_capture "$iface" "$TRACE_FILE"; then
        echo "All capture methods failed on interface '$iface'"
        return 1
    fi
    local capture_pid="$CAPTURE_PID"
    echo "Capture method: $CAPTURE_METHOD"

    echo "Interface: $iface"
    echo "Gateway: $gateway"
    echo "Ping target: $PING_TARGET"
    echo "SSH host: $SSH_HOST"

    # 1. ARP: explicitly probe the gateway's MAC via arping. This does
    #    not depend on whether the neighbor cache happens to already
    #    be warm (unlike just flushing the cache and hoping ordinary
    #    traffic re-triggers resolution, which is not reliable across
    #    all container network setups).
    arping -c 3 -I "$iface" "$gateway" > /dev/null 2>&1 || true

    # 2. ICMP: ordinary ping.
    ping -c 4 "$PING_TARGET" > /dev/null 2>&1 || true

    # 3. SSH: two separate sessions to the same server, close together
    #    in time, so Module 2 (separating conversations) has two
    #    distinct TCP streams to compare. We expect authentication to
    #    fail (no valid key) -- that's fine, the protocol-level
    #    exchange (TCP handshake, SSH version/algorithm negotiation)
    #    happens before that, which is everything these questions need.
    ssh -o ConnectTimeout=5 -o BatchMode=yes -o StrictHostKeyChecking=no \
        -T "git@${SSH_HOST}" > /dev/null 2>&1 || true
    sleep 1
    ssh -o ConnectTimeout=5 -o BatchMode=yes -o StrictHostKeyChecking=no \
        -T "git@${SSH_HOST}" > /dev/null 2>&1 || true

    sleep 3
    kill -INT "$capture_pid" 2>/dev/null
    wait "$capture_pid" 2>/dev/null

    if [ ! -s "$TRACE_FILE" ]; then
        echo "No trace file produced on interface '$iface'"
        return 1
    fi

    local packet_count
    packet_count=$(tshark -r "$TRACE_FILE" -T fields -e frame.number 2>/dev/null | wc -l)
    if [ "$packet_count" -lt 1 ]; then
        echo "Captured 0 packets on interface '$iface' -- wrong interface"
        return 1
    fi

    local arp_count icmp_count ssh_count
    arp_count=$(tshark -r "$TRACE_FILE" -Y arp -T fields -e frame.number 2>/dev/null | wc -l)
    icmp_count=$(tshark -r "$TRACE_FILE" -Y icmp -T fields -e frame.number 2>/dev/null | wc -l)
    ssh_count=$(tshark -r "$TRACE_FILE" -Y ssh -T fields -e frame.number 2>/dev/null | wc -l)
    echo "Captured $packet_count packets total (arp=$arp_count icmp=$icmp_count ssh=$ssh_count) on interface '$iface'"

    if [ "$arp_count" -lt 1 ] || [ "$icmp_count" -lt 1 ] || [ "$ssh_count" -lt 1 ]; then
        echo "Missing at least one required protocol on interface '$iface'"
        return 1
    fi

    return 0
}

success=0
while read -r iface; do
    if capture_and_generate_traffic "$iface"; then
        success=1
        break
    fi
done < <(candidate_interfaces)

if [ "$success" -ne 1 ]; then
    print_capture_diagnostics
    echo "ERROR: could not capture the required ARP/ICMP/SSH traffic on any candidate interface" >&2
    exit 1
fi

chmod 644 "$TRACE_FILE"
echo "Trace saved to $TRACE_FILE"
