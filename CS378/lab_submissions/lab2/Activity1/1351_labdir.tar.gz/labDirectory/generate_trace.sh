#!/bin/bash
#
# generate_trace.sh (p1 -- Action at a Host, Module 2)
#
# Runs once, automatically, at container boot. Picks ONE website,
# deterministically based on CLAB_USER_NAME (same student always gets
# the same website), and browses it over both HTTP and HTTPS,
# capturing the traffic to trace.pcapng in your home directory.
#
# Module 1 (the /etc/services / /etc/protocols / loopback questions)
# needs no trace -- those are answered by inspecting your own machine.

set -uo pipefail

CLAB_USER_NAME="${CLAB_USER_NAME:-}"
if [ -z "$CLAB_USER_NAME" ]; then
    echo "WARNING: CLAB_USER_NAME is not set -- falling back to hostname." >&2
    CLAB_USER_NAME="$(hostname)"
fi

TRACE_FILE="$HOME/trace.pcapng"

# ---------------------------------------------------------------------------
# Deterministic, per-student pseudo-random selection.
#
# Same CLAB_USER_NAME -> same selection, every time. Different
# students get (most likely) different selections. This is NOT
# cryptographically meaningful -- it's just a stable, well-distributed
# ordering derived from a hash, used purely to pick which website a
# given student gets.
# ---------------------------------------------------------------------------
seeded_shuffle() {
    local salt="$1"; shift
    local item h
    for item in "$@"; do
        h=$(printf '%s' "${CLAB_USER_NAME}:${salt}:${item}" | sha256sum | cut -c1-16)
        echo "$h $item"
    done | sort | awk '{print $2}'
}

seeded_pick_one() {
    local salt="$1"; shift
    seeded_shuffle "$salt" "$@" | head -n1
}

SITES=(
    example.com
    iana.org
    ietf.org
    gnu.org
    kernel.org
    w3.org
    opensource.org
    freebsd.org
    openssl.org
    nginx.org
)

SITE="$(seeded_pick_one "p1-website" "${SITES[@]}")"

# ---------------------------------------------------------------------------
# Figure out which interface will actually see this container's traffic
# (same logic used by the wireshark-trace-analysis lab -- see that
# lab's generate_trace.sh for the full rationale). We avoid "any"
# because it strips real Ethernet headers, which this lab's questions
# depend on.
# ---------------------------------------------------------------------------
print_capture_diagnostics() {
    echo "----- capture diagnostics -----" >&2
    echo "whoami: $(whoami 2>&1)" >&2
    echo "id: $(id 2>&1)" >&2
    echo "effective capabilities (see 'capsh --decode=<hex>' to read):" >&2
    grep -E '^Cap(Inh|Prm|Eff|Bnd)' /proc/self/status 2>&1 >&2
    echo "ip -o link show:" >&2
    ip -o link show 2>&1 >&2
    echo "tshark -D:" >&2
    tshark -D 2>&1 >&2
    echo "dumpcap -D:" >&2
    dumpcap -D 2>&1 >&2
    echo "--------------------------------" >&2
    echo "If every interface (including 'any') fails with ioctl/setsockopt" >&2
    echo "errors like SIOCETHTOOL or SO_TIMESTAMPNS while running as root," >&2
    echo "this is usually NOT a script bug -- it means the container's" >&2
    echo "network stack does not support raw packet capture at all. This" >&2
    echo "is a known limitation on some Docker Desktop for Mac networking" >&2
    echo "modes. Check: (1) the container is run with --cap-add=NET_RAW" >&2
    echo "--cap-add=NET_ADMIN, (2) if running on Docker Desktop for Mac," >&2
    echo "try a real Linux Docker host, or a different Docker Desktop" >&2
    echo "network backend." >&2
}

candidate_interfaces() {
    local route_iface up_iface
    route_iface="$(ip -o route get 8.8.8.8 2>/dev/null \
        | awk '{for(i=1;i<=NF;i++) if ($i=="dev") {print $(i+1); exit}}')"
    up_iface="$(ip -o link show up 2>/dev/null \
        | awk -F': ' '{print $2}' | cut -d'@' -f1 | grep -v '^lo$' | head -n1)"

    local seen=" "
    for cand in "$route_iface" "eth0" "$up_iface"; do
        if [ -n "$cand" ] && [[ "$seen" != *" $cand "* ]]; then
            echo "$cand"
            seen="$seen$cand "
        fi
    done
    echo "any"
}

# ---------------------------------------------------------------------------
# Start a packet capture on the given interface, trying several
# strategies in turn.
#
# Some container/sandboxed network runtimes (restricted syscall
# surfaces, certain veth implementations) don't support the
# ETHTOOL_GET_TS_INFO ioctl or the SO_TIMESTAMPNS setsockopt that
# modern libpcap tries to use by default when starting a capture --
# and treats a failure there as fatal rather than falling back
# gracefully, even though the capture itself would otherwise work
# fine. Forcing the timestamp type to "host" (a plain kernel/software
# timestamp, not a hardware-timestamp query) sidesteps that. We try
# this with tshark first, then with tcpdump (which takes the same
# flag under a different name), then fall back to each tool's
# default behavior in case the flag itself isn't recognized on a
# given build.
#
# Sets the globals CAPTURE_PID and CAPTURE_METHOD on success.
# ---------------------------------------------------------------------------
CAPTURE_PID=""
CAPTURE_METHOD=""

start_capture() {
    local iface="$1" file="$2" log="/tmp/capture_attempt.log"
    local pid

    rm -f "$file"
    tshark -i "$iface" --time-stamp-type host -w "$file" -q > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tshark --time-stamp-type host"
        return 0
    fi
    echo "Capture method 'tshark --time-stamp-type host' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tcpdump -i "$iface" -j host -w "$file" > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tcpdump -j host"
        return 0
    fi
    echo "Capture method 'tcpdump -j host' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tcpdump -i "$iface" -w "$file" > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tcpdump (default)"
        return 0
    fi
    echo "Capture method 'tcpdump (default)' failed on '$iface':" >&2
    cat "$log" >&2

    rm -f "$file"
    tshark -i "$iface" -w "$file" -q > "$log" 2>&1 &
    pid=$!
    sleep 3
    if kill -0 "$pid" 2>/dev/null; then
        CAPTURE_PID="$pid"; CAPTURE_METHOD="tshark (default)"
        return 0
    fi
    echo "Capture method 'tshark (default)' failed on '$iface':" >&2
    cat "$log" >&2

    return 1
}

capture_and_generate_traffic() {
    local iface="$1"

    # Resolve the site to a single IPv4 address BEFORE capturing, and
    # pin every request to that exact address via curl --resolve. This
    # guarantees: (a) no DNS packets land in the trace (keeps it to
    # exactly the local machine + the web server, mirroring the
    # original static lab's clean 2-endpoint trace), and (b) every
    # request goes to the SAME server IP even if the site is behind a
    # CDN with multiple edge IPs.
    local remote_ip
    remote_ip="$(getent ahostsv4 "$SITE" 2>/dev/null | awk '{print $1; exit}')"
    if [ -z "$remote_ip" ]; then
        remote_ip="$(dig +short -4 "$SITE" 2>/dev/null | grep -E '^[0-9.]+$' | head -n1)"
    fi
    if [ -z "$remote_ip" ]; then
        echo "Could not resolve $SITE"
        return 1
    fi

    if ! start_capture "$iface" "$TRACE_FILE"; then
        echo "All capture methods failed on interface '$iface'"
        return 1
    fi
    local capture_pid="$CAPTURE_PID"
    echo "Capture method: $CAPTURE_METHOD"

    echo "Interface: $iface"
    echo "Site: $SITE ($remote_ip)"

    curl -s -m 8 --resolve "${SITE}:80:${remote_ip}"  -o /dev/null "http://${SITE}/"
    curl -s -m 8 --resolve "${SITE}:443:${remote_ip}" -o /dev/null "https://${SITE}/"
    curl -s -m 8 --resolve "${SITE}:443:${remote_ip}" -o /dev/null "https://${SITE}/robots.txt"
    curl -s -m 8 --resolve "${SITE}:443:${remote_ip}" -o /dev/null "https://${SITE}/favicon.ico"

    sleep 3
    kill -INT "$capture_pid" 2>/dev/null
    wait "$capture_pid" 2>/dev/null

    if [ ! -s "$TRACE_FILE" ]; then
        echo "No trace file produced on interface '$iface'"
        return 1
    fi

    local packet_count
    packet_count=$(tshark -r "$TRACE_FILE" -Y "ip.addr==${remote_ip}" -T fields -e frame.number 2>/dev/null | wc -l)
    if [ "$packet_count" -lt 1 ]; then
        echo "Captured 0 packets to/from ${remote_ip} on interface '$iface' -- wrong interface"
        return 1
    fi

    echo "Captured $packet_count packets to/from the web server on interface '$iface'"
    return 0
}

success=0
while read -r iface; do
    if capture_and_generate_traffic "$iface"; then
        success=1
        break
    fi
done < <(candidate_interfaces)

if [ "$success" -ne 1 ]; then
    print_capture_diagnostics
    echo "ERROR: could not capture any traffic on any candidate interface" >&2
    exit 1
fi

chmod 644 "$TRACE_FILE"
echo "Trace saved to $TRACE_FILE"
