public class ObjectSemantics {
    public static void main(String[] args) {
        Animal p2;
        p2 = new Monkey();
        p2.sound();
        p2.tail();
    }
}

class Animal {
    int x;
    int y;
    Animal() {
        x = y = 10;
    }
    void sound() {
        System.out.println("Animal's sound: " + y);
    }
    void tail() {
        System.out.println("Animal's tail");
    }
}
class Monkey extends Animal {
    int y;
    int z;
    Monkey() {
        // super();
        x = y = z = 20;
    }
    void tail() {
        System.out.println("Monkey's tail");
    }
}
