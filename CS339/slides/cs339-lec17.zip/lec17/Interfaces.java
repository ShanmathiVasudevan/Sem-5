interface Drawable {
    void draw();
}

abstract class Shape {
    abstract double area();
}

class Circle extends Shape implements Drawable {
    double r;
    Circle(double r) {
        this.r = r;
    }
    public void draw() {
        System.out.println("Drawing Circle with radius " + r);
    }
    public double area() {
        return Math.PI * r * r;
    }
}

class Rectangle extends Shape implements Drawable {
    int width, height;
    Rectangle(int w, int h) {
        width = w;
        height = h;
    }
    public void draw() {
        System.out.println("Drawing Rectangle with width " + width + " and height " + height);
    }
    public double area() {
        return width * height;
    }
}

enum Color { RED, BLUE, GREEN; }
abstract class UIElement {
    Color color;
    UIElement() {
        color = Color.RED;
    }
    abstract void click();
}
class Button extends UIElement implements Drawable {
    public void draw() {
        System.out.println("Drawing Button with color " + color);
    }
    public void click() {
        System.out.println("Button clicked");
    }
}

public class Interfaces {
    public static void main(String[] args) {
        Drawable[] items = new Drawable[3];
        items[0] = new Circle(5);
        items[1] = new Rectangle(3, 4);
        items[2] = new Button();

        for (Drawable d : items) {
            d.draw();
        }
    }
}
