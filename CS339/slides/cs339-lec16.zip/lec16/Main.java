public class Main {
    public static void main(String[] args) {
        Person p1 = new Professor("Albus", "Dumbledore");

        ArrogantProf p2 = new ArrogantProf("Severus", "Snape");

        Student s = new Student("Hermione", "Granger", 101);

        Course c = new Course(420, p2);
        c.addStudent(s);
        c.start();
    }
}
